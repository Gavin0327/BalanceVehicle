%% Input Signals
%HW Input

a2l_disp('vild_t_EncoderA', '', 0, 1, 'boolean', 'Encoder A Input');
a2l_disp('vold_n_Couter', '', 0, 255, 'uint8', 'Encoder A counter');
a2l_disp('vold_b_LED_flg', '', 0, 1, 'boolean', 'LED Output');