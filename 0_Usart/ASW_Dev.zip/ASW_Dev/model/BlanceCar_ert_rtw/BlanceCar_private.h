/*
 * File: BlanceCar_private.h
 *
 * Code generated for Simulink model 'BlanceCar'.
 *
 * Model version                  : 1.6
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Mon Nov 30 21:43:21 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BlanceCar_private_h_
#define RTW_HEADER_BlanceCar_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_BlanceCar_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
