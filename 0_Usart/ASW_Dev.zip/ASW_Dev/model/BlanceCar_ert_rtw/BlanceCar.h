/*
 * File: BlanceCar.h
 *
 * Code generated for Simulink model 'BlanceCar'.
 *
 * Model version                  : 1.6
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Mon Nov 30 21:43:21 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BlanceCar_h_
#define RTW_HEADER_BlanceCar_h_
#include <math.h>
#include <stddef.h>
#include <string.h>
#ifndef BlanceCar_COMMON_INCLUDES_
# define BlanceCar_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* BlanceCar_COMMON_INCLUDES_ */

#include "BlanceCar_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real32_T UnitDelay;                  /* '<S3>/Unit Delay' */
} B_BlanceCar_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real32_T UnitDelay_DSTATE;           /* '<S6>/Unit Delay' */
  real32_T UnitDelay_DSTATE_f;         /* '<S3>/Unit Delay' */
  real32_T timer;                      /* '<Root>/Chart' */
  uint8_T UnitDelay_DSTATE_i;          /* '<S1>/Unit Delay' */
  boolean_T UnitDelay_DSTATE_b;        /* '<S5>/Unit Delay' */
  boolean_T UnitDelay_DSTATE_e;        /* '<Root>/Unit Delay' */
  uint8_T is_c3_BlanceCar;             /* '<Root>/Chart' */
} DW_BlanceCar_T;

/* Real-time Model Data Structure */
struct tag_RTM_BlanceCar_T {
  const char_T * volatile errorStatus;
};

/* Block signals (default storage) */
extern B_BlanceCar_T BlanceCar_B;

/* Block states (default storage) */
extern DW_BlanceCar_T BlanceCar_DW;

/* Model entry point functions */
extern void BlanceCar_initialize(void);
extern void BlanceCar_step(void);
extern void BlanceCar_terminate(void);

/* Exported data declaration */

/* Declaration for custom storage class: R_Global */
extern boolean_T vild_t_EncoderA;      /* Encoder A Input */
extern boolean_T vold_b_LED_flg;       /* LED Output */
extern uint8_T vold_n_Couter;          /* Encoder A counter */

/* Real-time Model object */
extern RT_MODEL_BlanceCar_T *const BlanceCar_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S7>/Switch1' : Eliminated due to constant selection input
 * Block '<S8>/Switch' : Eliminated due to constant selection input
 * Block '<S8>/Switch1' : Eliminated due to constant selection input
 * Block '<Root>/Constant3' : Unused code path elimination
 * Block '<Root>/Constant7' : Unused code path elimination
 * Block '<Root>/Constant8' : Unused code path elimination
 * Block '<S6>/Constant' : Unused code path elimination
 * Block '<S6>/Data Type Conversion' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'BlanceCar'
 * '<S1>'   : 'BlanceCar/Accumulator'
 * '<S2>'   : 'BlanceCar/Chart'
 * '<S3>'   : 'BlanceCar/Enabled Subsystem'
 * '<S4>'   : 'BlanceCar/Enabled Subsystem1'
 * '<S5>'   : 'BlanceCar/Rising_Detect'
 * '<S6>'   : 'BlanceCar/Timer'
 * '<S7>'   : 'BlanceCar/Accumulator/Selector'
 * '<S8>'   : 'BlanceCar/Timer/Selector'
 */
#endif                                 /* RTW_HEADER_BlanceCar_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
