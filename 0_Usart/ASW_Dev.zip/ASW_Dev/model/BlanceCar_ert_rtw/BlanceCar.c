/*
 * File: BlanceCar.c
 *
 * Code generated for Simulink model 'BlanceCar'.
 *
 * Model version                  : 1.6
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Mon Nov 30 21:43:21 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "BlanceCar.h"
#include "BlanceCar_private.h"

/* Named constants for Chart: '<Root>/Chart' */
#define BlanceCar_IN_LED_OFF           ((uint8_T)1U)
#define BlanceCar_IN_LED_ON            ((uint8_T)2U)

/* Exported data definition */

/* Definition for custom storage class: R_Global */
boolean_T vild_t_EncoderA;             /* Encoder A Input */
boolean_T vold_b_LED_flg;              /* LED Output */
uint8_T vold_n_Couter;                 /* Encoder A counter */

/* Block signals (default storage) */
B_BlanceCar_T BlanceCar_B;

/* Block states (default storage) */
DW_BlanceCar_T BlanceCar_DW;

/* Real-time model */
RT_MODEL_BlanceCar_T BlanceCar_M_;
RT_MODEL_BlanceCar_T *const BlanceCar_M = &BlanceCar_M_;

/* Model step function */
void BlanceCar_step(void)
{
  int32_T superStepCount;
  boolean_T isStable;

  /* Switch: '<S7>/Switch' incorporates:
   *  Inport: '<Root>/vild_t_EncoderA'
   *  Logic: '<S5>/Logical Operator'
   *  Logic: '<S5>/Logical Operator1'
   *  Sum: '<S1>/Sum'
   *  UnitDelay: '<S1>/Unit Delay'
   *  UnitDelay: '<S5>/Unit Delay'
   */
  BlanceCar_DW.UnitDelay_DSTATE_i = (uint8_T)(real32_T)(int32_T)fmodf((real32_T)
    ((vild_t_EncoderA && (!BlanceCar_DW.UnitDelay_DSTATE_b)) +
     BlanceCar_DW.UnitDelay_DSTATE_i), 256.0F);

  /* Sum: '<S6>/Sum' incorporates:
   *  Constant: '<Root>/Constant9'
   *  UnitDelay: '<S6>/Unit Delay'
   */
  BlanceCar_DW.UnitDelay_DSTATE += 0.001F;

  /* Outputs for Enabled SubSystem: '<Root>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S3>/Enable'
   */
  /* UnitDelay: '<Root>/Unit Delay' */
  if (BlanceCar_DW.UnitDelay_DSTATE_e) {
    /* UnitDelay: '<S3>/Unit Delay' */
    BlanceCar_B.UnitDelay = BlanceCar_DW.UnitDelay_DSTATE_f;

    /* Update for UnitDelay: '<S3>/Unit Delay' incorporates:
     *  UnitDelay: '<S6>/Unit Delay'
     */
    BlanceCar_DW.UnitDelay_DSTATE_f = BlanceCar_DW.UnitDelay_DSTATE;
  }

  /* End of UnitDelay: '<Root>/Unit Delay' */
  /* End of Outputs for SubSystem: '<Root>/Enabled Subsystem' */

  /* RelationalOperator: '<Root>/Relational Operator' incorporates:
   *  Constant: '<Root>/Constant10'
   *  Sum: '<Root>/Sum1'
   *  UnitDelay: '<S6>/Unit Delay'
   */
  BlanceCar_DW.UnitDelay_DSTATE_e = (BlanceCar_DW.UnitDelay_DSTATE -
    BlanceCar_B.UnitDelay >= 1.0F);

  /* Outputs for Enabled SubSystem: '<Root>/Enabled Subsystem1' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  if (BlanceCar_DW.UnitDelay_DSTATE_e) {
    /* SignalConversion: '<S4>/Signal Conversion' incorporates:
     *  UnitDelay: '<S1>/Unit Delay'
     */
    vold_n_Couter = BlanceCar_DW.UnitDelay_DSTATE_i;
  }

  /* End of Outputs for SubSystem: '<Root>/Enabled Subsystem1' */

  /* Chart: '<Root>/Chart' */
  superStepCount = 0;
  do {
    isStable = true;
    if (BlanceCar_DW.is_c3_BlanceCar == BlanceCar_IN_LED_OFF) {
      if (BlanceCar_DW.timer >= 0.5F) {
        isStable = false;
        BlanceCar_DW.is_c3_BlanceCar = BlanceCar_IN_LED_ON;
        vold_b_LED_flg = false;
        BlanceCar_DW.timer = 0.0F;
      } else {
        BlanceCar_DW.timer += 0.01F;
      }
    } else if (BlanceCar_DW.timer >= 0.5F) {
      isStable = false;
      BlanceCar_DW.is_c3_BlanceCar = BlanceCar_IN_LED_OFF;
      vold_b_LED_flg = true;
      BlanceCar_DW.timer = 0.0F;
    } else {
      BlanceCar_DW.timer += 0.01F;
    }

    superStepCount++;
  } while ((!isStable) && ((uint32_T)superStepCount <= 1000U));

  /* Update for UnitDelay: '<S5>/Unit Delay' incorporates:
   *  Inport: '<Root>/vild_t_EncoderA'
   */
  BlanceCar_DW.UnitDelay_DSTATE_b = vild_t_EncoderA;
}

/* Model initialize function */
void BlanceCar_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(BlanceCar_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &BlanceCar_B), 0,
                sizeof(B_BlanceCar_T));

  /* states (dwork) */
  (void) memset((void *)&BlanceCar_DW, 0,
                sizeof(DW_BlanceCar_T));

  /* SystemInitialize for Enabled SubSystem: '<Root>/Enabled Subsystem' */
  /* InitializeConditions for UnitDelay: '<S3>/Unit Delay' */
  BlanceCar_DW.UnitDelay_DSTATE_f = -1.0F;

  /* End of SystemInitialize for SubSystem: '<Root>/Enabled Subsystem' */

  /* Chart: '<Root>/Chart' */
  BlanceCar_DW.is_c3_BlanceCar = BlanceCar_IN_LED_ON;
  BlanceCar_DW.timer = 0.0F;
}

/* Model terminate function */
void BlanceCar_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
